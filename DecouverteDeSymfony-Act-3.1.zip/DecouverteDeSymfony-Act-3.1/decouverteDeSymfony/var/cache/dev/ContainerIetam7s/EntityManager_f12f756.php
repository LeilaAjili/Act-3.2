<?php

class EntityManager_f12f756 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $valueHolder6178d74bc6a50307251820 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer6178d74bc6a58723799534 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties6178d74bc6a36242355940 = array(
        
    );

    /**
     * {@inheritDoc}
     */
    public function getConnection()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getConnection', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getConnection();
    }

    /**
     * {@inheritDoc}
     */
    public function getMetadataFactory()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getMetadataFactory', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getMetadataFactory();
    }

    /**
     * {@inheritDoc}
     */
    public function getExpressionBuilder()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getExpressionBuilder', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getExpressionBuilder();
    }

    /**
     * {@inheritDoc}
     */
    public function beginTransaction()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'beginTransaction', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->beginTransaction();
    }

    /**
     * {@inheritDoc}
     */
    public function getCache()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getCache', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getCache();
    }

    /**
     * {@inheritDoc}
     */
    public function transactional($func)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'transactional', array('func' => $func), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->transactional($func);
    }

    /**
     * {@inheritDoc}
     */
    public function commit()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'commit', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->commit();
    }

    /**
     * {@inheritDoc}
     */
    public function rollback()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'rollback', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->rollback();
    }

    /**
     * {@inheritDoc}
     */
    public function getClassMetadata($className)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getClassMetadata', array('className' => $className), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getClassMetadata($className);
    }

    /**
     * {@inheritDoc}
     */
    public function createQuery($dql = '')
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'createQuery', array('dql' => $dql), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->createQuery($dql);
    }

    /**
     * {@inheritDoc}
     */
    public function createNamedQuery($name)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'createNamedQuery', array('name' => $name), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->createNamedQuery($name);
    }

    /**
     * {@inheritDoc}
     */
    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->createNativeQuery($sql, $rsm);
    }

    /**
     * {@inheritDoc}
     */
    public function createNamedNativeQuery($name)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->createNamedNativeQuery($name);
    }

    /**
     * {@inheritDoc}
     */
    public function createQueryBuilder()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'createQueryBuilder', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->createQueryBuilder();
    }

    /**
     * {@inheritDoc}
     */
    public function flush($entity = null)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'flush', array('entity' => $entity), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->flush($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function find($entityName, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'find', array('entityName' => $entityName, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->find($entityName, $id, $lockMode, $lockVersion);
    }

    /**
     * {@inheritDoc}
     */
    public function getReference($entityName, $id)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getReference($entityName, $id);
    }

    /**
     * {@inheritDoc}
     */
    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getPartialReference($entityName, $identifier);
    }

    /**
     * {@inheritDoc}
     */
    public function clear($entityName = null)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'clear', array('entityName' => $entityName), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->clear($entityName);
    }

    /**
     * {@inheritDoc}
     */
    public function close()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'close', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->close();
    }

    /**
     * {@inheritDoc}
     */
    public function persist($entity)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'persist', array('entity' => $entity), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->persist($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function remove($entity)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'remove', array('entity' => $entity), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->remove($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function refresh($entity)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'refresh', array('entity' => $entity), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->refresh($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function detach($entity)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'detach', array('entity' => $entity), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->detach($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function merge($entity)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'merge', array('entity' => $entity), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->merge($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function copy($entity, $deep = false)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->copy($entity, $deep);
    }

    /**
     * {@inheritDoc}
     */
    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->lock($entity, $lockMode, $lockVersion);
    }

    /**
     * {@inheritDoc}
     */
    public function getRepository($entityName)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getRepository', array('entityName' => $entityName), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getRepository($entityName);
    }

    /**
     * {@inheritDoc}
     */
    public function contains($entity)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'contains', array('entity' => $entity), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->contains($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function getEventManager()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getEventManager', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getEventManager();
    }

    /**
     * {@inheritDoc}
     */
    public function getConfiguration()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getConfiguration', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getConfiguration();
    }

    /**
     * {@inheritDoc}
     */
    public function isOpen()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'isOpen', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->isOpen();
    }

    /**
     * {@inheritDoc}
     */
    public function getUnitOfWork()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getUnitOfWork', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getUnitOfWork();
    }

    /**
     * {@inheritDoc}
     */
    public function getHydrator($hydrationMode)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getHydrator($hydrationMode);
    }

    /**
     * {@inheritDoc}
     */
    public function newHydrator($hydrationMode)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->newHydrator($hydrationMode);
    }

    /**
     * {@inheritDoc}
     */
    public function getProxyFactory()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getProxyFactory', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getProxyFactory();
    }

    /**
     * {@inheritDoc}
     */
    public function initializeObject($obj)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'initializeObject', array('obj' => $obj), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->initializeObject($obj);
    }

    /**
     * {@inheritDoc}
     */
    public function getFilters()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'getFilters', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->getFilters();
    }

    /**
     * {@inheritDoc}
     */
    public function isFiltersStateClean()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'isFiltersStateClean', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->isFiltersStateClean();
    }

    /**
     * {@inheritDoc}
     */
    public function hasFilters()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'hasFilters', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return $this->valueHolder6178d74bc6a50307251820->hasFilters();
    }

    /**
     * @override constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public function __construct($initializer)
    {
        $this->initializer6178d74bc6a58723799534 = $initializer;
    }

    /**
     * @param string $name
     */
    public function & __get($name)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, '__get', array('name' => $name), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        if (isset(self::$publicProperties6178d74bc6a36242355940[$name])) {
            return $this->valueHolder6178d74bc6a50307251820->$name;
        }

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6178d74bc6a50307251820;

            $backtrace = debug_backtrace(false);
            trigger_error('Undefined property: ' . get_parent_class($this) . '::$' . $name . ' in ' . $backtrace[0]['file'] . ' on line ' . $backtrace[0]['line'], \E_USER_NOTICE);
            return $targetObject->$name;;
            return;
        }

        $targetObject = $this->valueHolder6178d74bc6a50307251820;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    /**
     * @param string $name
     * @param mixed $value
     */
    public function __set($name, $value)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6178d74bc6a50307251820;

            return $targetObject->$name = $value;;
            return;
        }

        $targetObject = $this->valueHolder6178d74bc6a50307251820;
        $accessor = function & () use ($targetObject, $name, $value) {
            return $targetObject->$name = $value;
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    /**
     * @param string $name
     */
    public function __isset($name)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, '__isset', array('name' => $name), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6178d74bc6a50307251820;

            return isset($targetObject->$name);;
            return;
        }

        $targetObject = $this->valueHolder6178d74bc6a50307251820;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    /**
     * @param string $name
     */
    public function __unset($name)
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, '__unset', array('name' => $name), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6178d74bc6a50307251820;

            unset($targetObject->$name);;
            return;
        }

        $targetObject = $this->valueHolder6178d74bc6a50307251820;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __clone()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, '__clone', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        $this->valueHolder6178d74bc6a50307251820 = clone $this->valueHolder6178d74bc6a50307251820;
    }

    public function __sleep()
    {
        $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, '__sleep', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;

        return array('valueHolder6178d74bc6a50307251820');
    }

    public function __wakeup()
    {
    }

    /**
     * {@inheritDoc}
     */
    public function setProxyInitializer(\Closure $initializer = null)
    {
        $this->initializer6178d74bc6a58723799534 = $initializer;
    }

    /**
     * {@inheritDoc}
     */
    public function getProxyInitializer()
    {
        return $this->initializer6178d74bc6a58723799534;
    }

    /**
     * {@inheritDoc}
     */
    public function initializeProxy()
    {
        return $this->initializer6178d74bc6a58723799534 && ($this->initializer6178d74bc6a58723799534->__invoke($valueHolder6178d74bc6a50307251820, $this, 'initializeProxy', array(), $this->initializer6178d74bc6a58723799534) || 1) && $this->valueHolder6178d74bc6a50307251820 = $valueHolder6178d74bc6a50307251820;
    }

    /**
     * {@inheritDoc}
     */
    public function isProxyInitialized()
    {
        return null !== $this->valueHolder6178d74bc6a50307251820;
    }

    /**
     * {@inheritDoc}
     */
    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder6178d74bc6a50307251820;
    }


}
