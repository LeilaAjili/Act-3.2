<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if (substr($pathinfo, -1) !== '/') {
                        return array_replace($ret, $this->redirect($pathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // article_list
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\ArticleController::index',  '_route' => 'article_list',);
            if (substr($pathinfo, -1) !== '/') {
                return array_replace($ret, $this->redirect($pathinfo.'/', 'article_list'));
            }

            return $ret;
        }

        // article_show
        if (0 === strpos($pathinfo, '/article') && preg_match('#^/article/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'article_show')), array (  '_controller' => 'AppBundle\\Controller\\ArticleController::schow',));
        }

        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
            if (substr($pathinfo, -1) !== '/') {
                return array_replace($ret, $this->redirect($pathinfo.'/', 'homepage'));
            }

            return $ret;
        }

        if (0 === strpos($pathinfo, '/create')) {
            // create-product
            if (0 === strpos($pathinfo, '/create-product') && preg_match('#^/create\\-product/(?P<label>[^/]++)/(?P<price>[^/]++)/(?P<quantity>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'create-product')), array (  '_controller' => 'AppBundle\\Controller\\ProduitController::createProduct',));
            }

            // user_create
            if ('/create' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::createUser',  '_route' => 'user_create',);
            }

        }

        // edit-product
        if (0 === strpos($pathinfo, '/edit-product') && preg_match('#^/edit\\-product/(?P<id>[^/]++)/(?P<label>[^/]++)/(?P<price>[^/]++)/(?P<quantity>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'edit-product')), array (  '_controller' => 'AppBundle\\Controller\\ProduitController::editProduct',));
        }

        if (0 === strpos($pathinfo, '/get')) {
            // get-product
            if (0 === strpos($pathinfo, '/get-product') && preg_match('#^/get\\-product/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'get-product')), array (  '_controller' => 'AppBundle\\Controller\\ProduitController::getProduct',));
            }

            // get-all-products
            if ('/get-all-products' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ProduitController::getAllProducts',  '_route' => 'get-all-products',);
            }

            // Users List
            if ('/getAll' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::index',  '_route' => 'Users List',);
            }

            // getUserById
            if (0 === strpos($pathinfo, '/getUserById') && preg_match('#^/getUserById/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'getUserById')), array (  '_controller' => 'AppBundle\\Controller\\UserController::findUserById',));
            }

            // getUserByCity
            if (0 === strpos($pathinfo, '/getUserByCity') && preg_match('#^/getUserByCity/(?P<city>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'getUserByCity')), array (  '_controller' => 'AppBundle\\Controller\\UserController::findAllByCity',));
            }

        }

        // user_show
        if (0 === strpos($pathinfo, '/user') && preg_match('#^/user/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_show')), array (  '_controller' => 'AppBundle\\Controller\\UserController::show',));
        }

        if (0 === strpos($pathinfo, '/findBy')) {
            // getUserByCityAndEmail
            if (0 === strpos($pathinfo, '/findByAddressAndEmail') && preg_match('#^/findByAddressAndEmail/(?P<address>[^/]++)/(?P<email>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'getUserByCityAndEmail')), array (  '_controller' => 'AppBundle\\Controller\\UserController::findByAddressAndName',));
            }

            // findByAddressAndNameNative
            if (0 === strpos($pathinfo, '/findByAddressAndNameNative') && preg_match('#^/findByAddressAndNameNative/(?P<adress>[^/]++)/(?P<name>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'findByAddressAndNameNative')), array (  '_controller' => 'AppBundle\\Controller\\UserController::findByAddressAndNameNative',));
            }

            // findByIdNative
            if (0 === strpos($pathinfo, '/findByIdNative') && preg_match('#^/findByIdNative/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'findByIdNative')), array (  '_controller' => 'AppBundle\\Controller\\UserController::findByIdNative',));
            }

        }

        // findAllByCityNative
        if (0 === strpos($pathinfo, '/findAllByCityNative') && preg_match('#^/findAllByCityNative/(?P<city>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'findAllByCityNative')), array (  '_controller' => 'AppBundle\\Controller\\UserController::findAllByCityNative',));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
