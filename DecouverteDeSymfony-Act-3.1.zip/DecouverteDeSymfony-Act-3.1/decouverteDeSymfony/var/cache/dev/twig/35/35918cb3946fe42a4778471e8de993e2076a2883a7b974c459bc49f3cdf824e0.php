<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_8dc19400dffc6207b2952c9d3259751d3466efed668a62b0dc7966d48142f2d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3eeb29989a2e73314311505215da55404a5e84960e0ac4fd862bd9b3dc467864 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3eeb29989a2e73314311505215da55404a5e84960e0ac4fd862bd9b3dc467864->enter($__internal_3eeb29989a2e73314311505215da55404a5e84960e0ac4fd862bd9b3dc467864_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_63c7ff71cecfff04a2f8380657bdd59f8995590f9daef6ac622aa224592450a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63c7ff71cecfff04a2f8380657bdd59f8995590f9daef6ac622aa224592450a1->enter($__internal_63c7ff71cecfff04a2f8380657bdd59f8995590f9daef6ac622aa224592450a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_3eeb29989a2e73314311505215da55404a5e84960e0ac4fd862bd9b3dc467864->leave($__internal_3eeb29989a2e73314311505215da55404a5e84960e0ac4fd862bd9b3dc467864_prof);

        
        $__internal_63c7ff71cecfff04a2f8380657bdd59f8995590f9daef6ac622aa224592450a1->leave($__internal_63c7ff71cecfff04a2f8380657bdd59f8995590f9daef6ac622aa224592450a1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
