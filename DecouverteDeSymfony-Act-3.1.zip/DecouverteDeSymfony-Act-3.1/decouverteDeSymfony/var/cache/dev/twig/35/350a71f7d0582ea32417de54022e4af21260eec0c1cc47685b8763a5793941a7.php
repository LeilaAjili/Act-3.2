<?php

/* @WebProfiler/Profiler/info.html.twig */
class __TwigTemplate_99edfa09d4b87a694806164ee5d791a239314d292bb5d198da36ac375123bf78 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Profiler/info.html.twig", 1);
        $this->blocks = array(
            'summary' => array($this, 'block_summary'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e748a6458991f0d5c68f1cbae3843807835eff517bb6992f4d7964a43b29152 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e748a6458991f0d5c68f1cbae3843807835eff517bb6992f4d7964a43b29152->enter($__internal_6e748a6458991f0d5c68f1cbae3843807835eff517bb6992f4d7964a43b29152_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/info.html.twig"));

        $__internal_6312f5ae2650936a71448848cab254bfe46876cf16f51cd89dda1c8b392311cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6312f5ae2650936a71448848cab254bfe46876cf16f51cd89dda1c8b392311cb->enter($__internal_6312f5ae2650936a71448848cab254bfe46876cf16f51cd89dda1c8b392311cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/info.html.twig"));

        // line 3
        $context["messages"] = array("no_token" => array("status" => "error", "title" => (((((        // line 6
array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : ("")) == "latest")) ? ("There are no profiles") : ("Token not found")), "message" => (((((        // line 7
array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : ("")) == "latest")) ? ("No profiles found in the database.") : ((("Token \"" . ((array_key_exists("token", $context)) ? (_twig_default_filter(($context["token"] ?? $this->getContext($context, "token")), "")) : (""))) . "\" was not found in the database.")))));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6e748a6458991f0d5c68f1cbae3843807835eff517bb6992f4d7964a43b29152->leave($__internal_6e748a6458991f0d5c68f1cbae3843807835eff517bb6992f4d7964a43b29152_prof);

        
        $__internal_6312f5ae2650936a71448848cab254bfe46876cf16f51cd89dda1c8b392311cb->leave($__internal_6312f5ae2650936a71448848cab254bfe46876cf16f51cd89dda1c8b392311cb_prof);

    }

    // line 11
    public function block_summary($context, array $blocks = array())
    {
        $__internal_f363717bdb815199f556d12c6ccf101158592f1cefcb1679458fa66d7b3014ca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f363717bdb815199f556d12c6ccf101158592f1cefcb1679458fa66d7b3014ca->enter($__internal_f363717bdb815199f556d12c6ccf101158592f1cefcb1679458fa66d7b3014ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "summary"));

        $__internal_e111b11002b7a5a785a74282744ab8d9b7c6acf38b0890823abf541e4331dbe6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e111b11002b7a5a785a74282744ab8d9b7c6acf38b0890823abf541e4331dbe6->enter($__internal_e111b11002b7a5a785a74282744ab8d9b7c6acf38b0890823abf541e4331dbe6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "summary"));

        // line 12
        echo "    <div class=\"status status-";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "status", array()), "html", null, true);
        echo "\">
        <div class=\"container\">
            <h2>";
        // line 14
        echo twig_escape_filter($this->env, twig_title_string_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "status", array())), "html", null, true);
        echo "</h2>
        </div>
    </div>
";
        
        $__internal_e111b11002b7a5a785a74282744ab8d9b7c6acf38b0890823abf541e4331dbe6->leave($__internal_e111b11002b7a5a785a74282744ab8d9b7c6acf38b0890823abf541e4331dbe6_prof);

        
        $__internal_f363717bdb815199f556d12c6ccf101158592f1cefcb1679458fa66d7b3014ca->leave($__internal_f363717bdb815199f556d12c6ccf101158592f1cefcb1679458fa66d7b3014ca_prof);

    }

    // line 19
    public function block_panel($context, array $blocks = array())
    {
        $__internal_9315c346b70c8bedda53286de1d369ca5becbbeb1eb698c761ad283cde217e3f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9315c346b70c8bedda53286de1d369ca5becbbeb1eb698c761ad283cde217e3f->enter($__internal_9315c346b70c8bedda53286de1d369ca5becbbeb1eb698c761ad283cde217e3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_acfa83285f62b8aa82b1d586d89eac3f8bd94f3581cf46ecac82de46d1fb1695 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acfa83285f62b8aa82b1d586d89eac3f8bd94f3581cf46ecac82de46d1fb1695->enter($__internal_acfa83285f62b8aa82b1d586d89eac3f8bd94f3581cf46ecac82de46d1fb1695_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 20
        echo "    <h2>";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "title", array()), "html", null, true);
        echo "</h2>
    <p>";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["messages"] ?? $this->getContext($context, "messages")), ($context["about"] ?? $this->getContext($context, "about")), array(), "array"), "message", array()), "html", null, true);
        echo "</p>
";
        
        $__internal_acfa83285f62b8aa82b1d586d89eac3f8bd94f3581cf46ecac82de46d1fb1695->leave($__internal_acfa83285f62b8aa82b1d586d89eac3f8bd94f3581cf46ecac82de46d1fb1695_prof);

        
        $__internal_9315c346b70c8bedda53286de1d369ca5becbbeb1eb698c761ad283cde217e3f->leave($__internal_9315c346b70c8bedda53286de1d369ca5becbbeb1eb698c761ad283cde217e3f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/info.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 21,  84 => 20,  75 => 19,  61 => 14,  55 => 12,  46 => 11,  36 => 1,  34 => 7,  33 => 6,  32 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% set messages = {
    'no_token' : {
        status:  'error',
        title:   (token|default('') == 'latest') ? 'There are no profiles' : 'Token not found',
        message: (token|default('') == 'latest') ? 'No profiles found in the database.' : 'Token \"' ~ token|default('') ~ '\" was not found in the database.'
    }
} %}

{% block summary %}
    <div class=\"status status-{{ messages[about].status }}\">
        <div class=\"container\">
            <h2>{{ messages[about].status|title }}</h2>
        </div>
    </div>
{% endblock %}

{% block panel %}
    <h2>{{ messages[about].title }}</h2>
    <p>{{ messages[about].message }}</p>
{% endblock %}
", "@WebProfiler/Profiler/info.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\info.html.twig");
    }
}
