<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_057fd96f4c4f70718795b3438c121e5106fdf92611d5b2d0ecf51ec91f78baed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49cb5552da4906faae6dbb50562819028391bec7fbff9fd520add5e8c84a78de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_49cb5552da4906faae6dbb50562819028391bec7fbff9fd520add5e8c84a78de->enter($__internal_49cb5552da4906faae6dbb50562819028391bec7fbff9fd520add5e8c84a78de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_50483e8d783f7245b4fd74312370dd60f38e99c207e8b5ea09721877d7b8e309 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50483e8d783f7245b4fd74312370dd60f38e99c207e8b5ea09721877d7b8e309->enter($__internal_50483e8d783f7245b4fd74312370dd60f38e99c207e8b5ea09721877d7b8e309_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_49cb5552da4906faae6dbb50562819028391bec7fbff9fd520add5e8c84a78de->leave($__internal_49cb5552da4906faae6dbb50562819028391bec7fbff9fd520add5e8c84a78de_prof);

        
        $__internal_50483e8d783f7245b4fd74312370dd60f38e99c207e8b5ea09721877d7b8e309->leave($__internal_50483e8d783f7245b4fd74312370dd60f38e99c207e8b5ea09721877d7b8e309_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
