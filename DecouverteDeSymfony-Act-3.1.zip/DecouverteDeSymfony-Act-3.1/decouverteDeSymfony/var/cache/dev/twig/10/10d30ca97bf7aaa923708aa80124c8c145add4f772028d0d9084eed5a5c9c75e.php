<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0a49730a4415c52dbae0bde59acb7a1499983a905e405c913fd1a90537bf38c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f2a64048bbe1d126d7fe127c3fdc37d6e5294650caff773a287411375272b9b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f2a64048bbe1d126d7fe127c3fdc37d6e5294650caff773a287411375272b9b->enter($__internal_5f2a64048bbe1d126d7fe127c3fdc37d6e5294650caff773a287411375272b9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_3ab93c3228723e3268e4e979c3a64f1b13e832b764200e1decf39eaa3ba7be1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ab93c3228723e3268e4e979c3a64f1b13e832b764200e1decf39eaa3ba7be1e->enter($__internal_3ab93c3228723e3268e4e979c3a64f1b13e832b764200e1decf39eaa3ba7be1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5f2a64048bbe1d126d7fe127c3fdc37d6e5294650caff773a287411375272b9b->leave($__internal_5f2a64048bbe1d126d7fe127c3fdc37d6e5294650caff773a287411375272b9b_prof);

        
        $__internal_3ab93c3228723e3268e4e979c3a64f1b13e832b764200e1decf39eaa3ba7be1e->leave($__internal_3ab93c3228723e3268e4e979c3a64f1b13e832b764200e1decf39eaa3ba7be1e_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ef30d98e7bb11c26a7532d7b0f3c7a70a073bbbbb90cae32244351a58d2a3854 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ef30d98e7bb11c26a7532d7b0f3c7a70a073bbbbb90cae32244351a58d2a3854->enter($__internal_ef30d98e7bb11c26a7532d7b0f3c7a70a073bbbbb90cae32244351a58d2a3854_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_4850eec7f675e5100048f9e949e320254531b160f231c0efbcaa928ad02d9db5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4850eec7f675e5100048f9e949e320254531b160f231c0efbcaa928ad02d9db5->enter($__internal_4850eec7f675e5100048f9e949e320254531b160f231c0efbcaa928ad02d9db5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_4850eec7f675e5100048f9e949e320254531b160f231c0efbcaa928ad02d9db5->leave($__internal_4850eec7f675e5100048f9e949e320254531b160f231c0efbcaa928ad02d9db5_prof);

        
        $__internal_ef30d98e7bb11c26a7532d7b0f3c7a70a073bbbbb90cae32244351a58d2a3854->leave($__internal_ef30d98e7bb11c26a7532d7b0f3c7a70a073bbbbb90cae32244351a58d2a3854_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_37ca56b7a455a4f31ad74eda6849a9d648fd4e1c073cd7eb02118307011e4eab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37ca56b7a455a4f31ad74eda6849a9d648fd4e1c073cd7eb02118307011e4eab->enter($__internal_37ca56b7a455a4f31ad74eda6849a9d648fd4e1c073cd7eb02118307011e4eab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_b7c942baff620be50f5e33c936dbb903f84676428009c60f89fed80f82c286f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7c942baff620be50f5e33c936dbb903f84676428009c60f89fed80f82c286f1->enter($__internal_b7c942baff620be50f5e33c936dbb903f84676428009c60f89fed80f82c286f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_b7c942baff620be50f5e33c936dbb903f84676428009c60f89fed80f82c286f1->leave($__internal_b7c942baff620be50f5e33c936dbb903f84676428009c60f89fed80f82c286f1_prof);

        
        $__internal_37ca56b7a455a4f31ad74eda6849a9d648fd4e1c073cd7eb02118307011e4eab->leave($__internal_37ca56b7a455a4f31ad74eda6849a9d648fd4e1c073cd7eb02118307011e4eab_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_db5f59ea2150ccfab42f63de11927728b0960c03e5a4ebbeab7ddb24978caa27 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db5f59ea2150ccfab42f63de11927728b0960c03e5a4ebbeab7ddb24978caa27->enter($__internal_db5f59ea2150ccfab42f63de11927728b0960c03e5a4ebbeab7ddb24978caa27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_461df9f103f41a24012ec319a640a9f237d7454dcecf3b185eaaa41018bbc7b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_461df9f103f41a24012ec319a640a9f237d7454dcecf3b185eaaa41018bbc7b3->enter($__internal_461df9f103f41a24012ec319a640a9f237d7454dcecf3b185eaaa41018bbc7b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_461df9f103f41a24012ec319a640a9f237d7454dcecf3b185eaaa41018bbc7b3->leave($__internal_461df9f103f41a24012ec319a640a9f237d7454dcecf3b185eaaa41018bbc7b3_prof);

        
        $__internal_db5f59ea2150ccfab42f63de11927728b0960c03e5a4ebbeab7ddb24978caa27->leave($__internal_db5f59ea2150ccfab42f63de11927728b0960c03e5a4ebbeab7ddb24978caa27_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
