<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_2a53bc253a0b4816d6894cf7a3fb288f9368a4ad6f2639f7d55629ac07c7171e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93b5ebfb0e1c6a885c672aa457f59cdb496d8218d5f7aec454f453dc4093583f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_93b5ebfb0e1c6a885c672aa457f59cdb496d8218d5f7aec454f453dc4093583f->enter($__internal_93b5ebfb0e1c6a885c672aa457f59cdb496d8218d5f7aec454f453dc4093583f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_ed7bf124d9257e7780d0437ba3e1a46269a61c89e7802a575b128a2897035c75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed7bf124d9257e7780d0437ba3e1a46269a61c89e7802a575b128a2897035c75->enter($__internal_ed7bf124d9257e7780d0437ba3e1a46269a61c89e7802a575b128a2897035c75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_93b5ebfb0e1c6a885c672aa457f59cdb496d8218d5f7aec454f453dc4093583f->leave($__internal_93b5ebfb0e1c6a885c672aa457f59cdb496d8218d5f7aec454f453dc4093583f_prof);

        
        $__internal_ed7bf124d9257e7780d0437ba3e1a46269a61c89e7802a575b128a2897035c75->leave($__internal_ed7bf124d9257e7780d0437ba3e1a46269a61c89e7802a575b128a2897035c75_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_98ea8849b3a5150fed0860674a28471a052f234bc6c3f029f09becaf028f6e89 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98ea8849b3a5150fed0860674a28471a052f234bc6c3f029f09becaf028f6e89->enter($__internal_98ea8849b3a5150fed0860674a28471a052f234bc6c3f029f09becaf028f6e89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_aad84b9a24c86cbbbe2de658b85deaf8f9f916ee491fe9f380e0ce602856845c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aad84b9a24c86cbbbe2de658b85deaf8f9f916ee491fe9f380e0ce602856845c->enter($__internal_aad84b9a24c86cbbbe2de658b85deaf8f9f916ee491fe9f380e0ce602856845c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_aad84b9a24c86cbbbe2de658b85deaf8f9f916ee491fe9f380e0ce602856845c->leave($__internal_aad84b9a24c86cbbbe2de658b85deaf8f9f916ee491fe9f380e0ce602856845c_prof);

        
        $__internal_98ea8849b3a5150fed0860674a28471a052f234bc6c3f029f09becaf028f6e89->leave($__internal_98ea8849b3a5150fed0860674a28471a052f234bc6c3f029f09becaf028f6e89_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
