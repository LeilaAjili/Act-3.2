<?php

/* base.html.twig */
class __TwigTemplate_35a788ca461558bba9038e4c3f84ff08bc8c4a644fa3eb1893a42b9f45e0624c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb210c62a2f990be314a33be10853df38bc4e9cffc1ad1a8863b18e5f20016aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb210c62a2f990be314a33be10853df38bc4e9cffc1ad1a8863b18e5f20016aa->enter($__internal_bb210c62a2f990be314a33be10853df38bc4e9cffc1ad1a8863b18e5f20016aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a19bfaf257687fdcdd5bb06f5dfd4bed093f8066f0bf8eed319e4ec54413e88a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a19bfaf257687fdcdd5bb06f5dfd4bed093f8066f0bf8eed319e4ec54413e88a->enter($__internal_a19bfaf257687fdcdd5bb06f5dfd4bed093f8066f0bf8eed319e4ec54413e88a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link rel=\"stylesheet\" href=\"https://bootswatch.com/5/cosmo/bootstrap.min.css\">
        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>

        ";
        // line 13
        echo twig_include($this->env, $context, "inc/navbar.html.twig");
        echo "

        <div class=\"container\">
        ";
        // line 16
        $this->displayBlock('body', $context, $blocks);
        // line 17
        echo "        </div>
        
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js\" integrity=\"sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js\" integrity=\"sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13\" crossorigin=\"anonymous\"></script>

        ";
        // line 23
        $this->displayBlock('javascripts', $context, $blocks);
        // line 24
        echo "    </body>
</html>
";
        
        $__internal_bb210c62a2f990be314a33be10853df38bc4e9cffc1ad1a8863b18e5f20016aa->leave($__internal_bb210c62a2f990be314a33be10853df38bc4e9cffc1ad1a8863b18e5f20016aa_prof);

        
        $__internal_a19bfaf257687fdcdd5bb06f5dfd4bed093f8066f0bf8eed319e4ec54413e88a->leave($__internal_a19bfaf257687fdcdd5bb06f5dfd4bed093f8066f0bf8eed319e4ec54413e88a_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_db8e66e6976083adc407eff79c2900931b1270c72aebb8478512be2e5445f729 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db8e66e6976083adc407eff79c2900931b1270c72aebb8478512be2e5445f729->enter($__internal_db8e66e6976083adc407eff79c2900931b1270c72aebb8478512be2e5445f729_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_cdb49b46303728ee9096dd35ff96dc9ddb15caf97f72b331a0e48ca18d54a660 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdb49b46303728ee9096dd35ff96dc9ddb15caf97f72b331a0e48ca18d54a660->enter($__internal_cdb49b46303728ee9096dd35ff96dc9ddb15caf97f72b331a0e48ca18d54a660_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_cdb49b46303728ee9096dd35ff96dc9ddb15caf97f72b331a0e48ca18d54a660->leave($__internal_cdb49b46303728ee9096dd35ff96dc9ddb15caf97f72b331a0e48ca18d54a660_prof);

        
        $__internal_db8e66e6976083adc407eff79c2900931b1270c72aebb8478512be2e5445f729->leave($__internal_db8e66e6976083adc407eff79c2900931b1270c72aebb8478512be2e5445f729_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_76012ef1eacd99dfb12f94a7274112f5840f42dfc7781f4acf9497ca0a23eaff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76012ef1eacd99dfb12f94a7274112f5840f42dfc7781f4acf9497ca0a23eaff->enter($__internal_76012ef1eacd99dfb12f94a7274112f5840f42dfc7781f4acf9497ca0a23eaff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_7190d9add66f7551b035787df5d3b28014a286ed20c6e836d21c03fe8d24488c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7190d9add66f7551b035787df5d3b28014a286ed20c6e836d21c03fe8d24488c->enter($__internal_7190d9add66f7551b035787df5d3b28014a286ed20c6e836d21c03fe8d24488c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_7190d9add66f7551b035787df5d3b28014a286ed20c6e836d21c03fe8d24488c->leave($__internal_7190d9add66f7551b035787df5d3b28014a286ed20c6e836d21c03fe8d24488c_prof);

        
        $__internal_76012ef1eacd99dfb12f94a7274112f5840f42dfc7781f4acf9497ca0a23eaff->leave($__internal_76012ef1eacd99dfb12f94a7274112f5840f42dfc7781f4acf9497ca0a23eaff_prof);

    }

    // line 16
    public function block_body($context, array $blocks = array())
    {
        $__internal_c9776190c68eedc701825784f123993ec41ec8f87bfbe8e1a3599422d0df05d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9776190c68eedc701825784f123993ec41ec8f87bfbe8e1a3599422d0df05d3->enter($__internal_c9776190c68eedc701825784f123993ec41ec8f87bfbe8e1a3599422d0df05d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3429d10ce90604e0e9699cf32c98b97af71021388dd2844b3ff3732d1d31367e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3429d10ce90604e0e9699cf32c98b97af71021388dd2844b3ff3732d1d31367e->enter($__internal_3429d10ce90604e0e9699cf32c98b97af71021388dd2844b3ff3732d1d31367e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3429d10ce90604e0e9699cf32c98b97af71021388dd2844b3ff3732d1d31367e->leave($__internal_3429d10ce90604e0e9699cf32c98b97af71021388dd2844b3ff3732d1d31367e_prof);

        
        $__internal_c9776190c68eedc701825784f123993ec41ec8f87bfbe8e1a3599422d0df05d3->leave($__internal_c9776190c68eedc701825784f123993ec41ec8f87bfbe8e1a3599422d0df05d3_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_0bddb479336ed0d75d3887568f696476c86de1efd5bfdb1caa7e86a724fabdbc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0bddb479336ed0d75d3887568f696476c86de1efd5bfdb1caa7e86a724fabdbc->enter($__internal_0bddb479336ed0d75d3887568f696476c86de1efd5bfdb1caa7e86a724fabdbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_89a8a25abb29e32a36c555fa8992d51592c93880700d2c5ec363742ce92006f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89a8a25abb29e32a36c555fa8992d51592c93880700d2c5ec363742ce92006f5->enter($__internal_89a8a25abb29e32a36c555fa8992d51592c93880700d2c5ec363742ce92006f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_89a8a25abb29e32a36c555fa8992d51592c93880700d2c5ec363742ce92006f5->leave($__internal_89a8a25abb29e32a36c555fa8992d51592c93880700d2c5ec363742ce92006f5_prof);

        
        $__internal_0bddb479336ed0d75d3887568f696476c86de1efd5bfdb1caa7e86a724fabdbc->leave($__internal_0bddb479336ed0d75d3887568f696476c86de1efd5bfdb1caa7e86a724fabdbc_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 23,  116 => 16,  99 => 8,  81 => 5,  69 => 24,  67 => 23,  59 => 17,  57 => 16,  51 => 13,  43 => 9,  41 => 8,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>

        <link rel=\"stylesheet\" href=\"https://bootswatch.com/5/cosmo/bootstrap.min.css\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>

        {{ include('inc/navbar.html.twig') }}

        <div class=\"container\">
        {% block body %}{% endblock %}
        </div>
        
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js\" integrity=\"sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js\" integrity=\"sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13\" crossorigin=\"anonymous\"></script>

        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\app\\Resources\\views\\base.html.twig");
    }
}
