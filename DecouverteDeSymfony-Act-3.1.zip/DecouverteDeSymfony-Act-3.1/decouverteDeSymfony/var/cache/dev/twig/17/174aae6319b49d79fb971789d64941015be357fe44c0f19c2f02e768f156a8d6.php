<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_15cac7b37526b2c0b23674c767ddea7669c8a2217d38e99f500b014ea0bffba2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_688085e6de05c02b1f08e7e44152cb7c7565236d90132e6f976ee915b91d37e1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_688085e6de05c02b1f08e7e44152cb7c7565236d90132e6f976ee915b91d37e1->enter($__internal_688085e6de05c02b1f08e7e44152cb7c7565236d90132e6f976ee915b91d37e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_ce81ef8593fcf4be4061b08f4386c26145a0b0e9a308c9ad814c5e66ff5d5ab4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce81ef8593fcf4be4061b08f4386c26145a0b0e9a308c9ad814c5e66ff5d5ab4->enter($__internal_ce81ef8593fcf4be4061b08f4386c26145a0b0e9a308c9ad814c5e66ff5d5ab4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_688085e6de05c02b1f08e7e44152cb7c7565236d90132e6f976ee915b91d37e1->leave($__internal_688085e6de05c02b1f08e7e44152cb7c7565236d90132e6f976ee915b91d37e1_prof);

        
        $__internal_ce81ef8593fcf4be4061b08f4386c26145a0b0e9a308c9ad814c5e66ff5d5ab4->leave($__internal_ce81ef8593fcf4be4061b08f4386c26145a0b0e9a308c9ad814c5e66ff5d5ab4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
