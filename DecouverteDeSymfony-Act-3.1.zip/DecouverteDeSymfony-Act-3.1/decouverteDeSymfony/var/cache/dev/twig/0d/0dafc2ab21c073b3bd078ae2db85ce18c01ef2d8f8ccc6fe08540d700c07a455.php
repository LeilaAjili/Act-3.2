<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_33944acc91a79d68ad8603dfd0588129a2c4014c546b9111a9038c48c8395e84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_360f5dc2201f21e48e0ac0454f752cf4a7f396a04a76b69fa2ea6f40058e0a46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_360f5dc2201f21e48e0ac0454f752cf4a7f396a04a76b69fa2ea6f40058e0a46->enter($__internal_360f5dc2201f21e48e0ac0454f752cf4a7f396a04a76b69fa2ea6f40058e0a46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_fd5501a27958eff3438a8f7252e29e0e4daf3244f0bae2d0cd756c2448d5365c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd5501a27958eff3438a8f7252e29e0e4daf3244f0bae2d0cd756c2448d5365c->enter($__internal_fd5501a27958eff3438a8f7252e29e0e4daf3244f0bae2d0cd756c2448d5365c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_360f5dc2201f21e48e0ac0454f752cf4a7f396a04a76b69fa2ea6f40058e0a46->leave($__internal_360f5dc2201f21e48e0ac0454f752cf4a7f396a04a76b69fa2ea6f40058e0a46_prof);

        
        $__internal_fd5501a27958eff3438a8f7252e29e0e4daf3244f0bae2d0cd756c2448d5365c->leave($__internal_fd5501a27958eff3438a8f7252e29e0e4daf3244f0bae2d0cd756c2448d5365c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
