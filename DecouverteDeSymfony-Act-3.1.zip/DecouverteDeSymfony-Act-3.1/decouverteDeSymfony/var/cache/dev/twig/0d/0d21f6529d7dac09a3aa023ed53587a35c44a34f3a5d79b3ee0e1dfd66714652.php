<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_b549632acf015d162fb61593e0530139ac2730a4642372bdb7d60c6e3d7cbb7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d90d3de927cab72e0e2be2a2bb034ad1e18397a6fbbbd782dc01b4b64cf6735 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d90d3de927cab72e0e2be2a2bb034ad1e18397a6fbbbd782dc01b4b64cf6735->enter($__internal_7d90d3de927cab72e0e2be2a2bb034ad1e18397a6fbbbd782dc01b4b64cf6735_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_8f743616d24e0001ca3a5cb8c75d5fc2c04a6b5486c4ff32a1259e614863ee39 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f743616d24e0001ca3a5cb8c75d5fc2c04a6b5486c4ff32a1259e614863ee39->enter($__internal_8f743616d24e0001ca3a5cb8c75d5fc2c04a6b5486c4ff32a1259e614863ee39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_7d90d3de927cab72e0e2be2a2bb034ad1e18397a6fbbbd782dc01b4b64cf6735->leave($__internal_7d90d3de927cab72e0e2be2a2bb034ad1e18397a6fbbbd782dc01b4b64cf6735_prof);

        
        $__internal_8f743616d24e0001ca3a5cb8c75d5fc2c04a6b5486c4ff32a1259e614863ee39->leave($__internal_8f743616d24e0001ca3a5cb8c75d5fc2c04a6b5486c4ff32a1259e614863ee39_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
