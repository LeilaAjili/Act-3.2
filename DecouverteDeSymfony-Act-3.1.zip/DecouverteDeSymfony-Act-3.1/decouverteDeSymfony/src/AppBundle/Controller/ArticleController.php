<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Article;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;




class ArticleController extends Controller{

    /**
     * @Route("/", name="article_list")
     */

    public function index() {

        $articles = $this->getDoctrine()->getRepository(Article::class)->findAll();


        return $this->render('articles/index.html.twig', array('articles'=>$articles));
    }

   /**
     * @Route("/article/{id}", name="article_show")
     */

     public function schow($id){
         $article = $this->getDoctrine()->getRepository(Article::class)->find($id);

         return $this->render('articles/show.html.twig', array('article' => $article));
     }

   

     /*public function save (){

         $entityManager = $this->getDoctrine()->getManager();

         $article = new Article();

         $article->setTitle('Article 2');

         $article->setBody(' body 2');

         $entityManager->persist($article);

         $entityManager->flush();

         return new Response('saved article n'.$article->getId());




     }*/
}