<?php

namespace AppBundle\Controller;

use AppBundle\Repository\ProduitRepository;
use AppBundle\Entity\Produit;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;




class ProduitController extends Controller{

    /**
     * @Route("/create-product/{label}/{price}/{quantity}", name="create-product")
     */

    public function createProduct ($label, $price, $quantity){

       

        $product = new Produit();

        $product->setLabel($label);

        $product->setPrice($price);

        $product->setQuantity($quantity);

        $entityManager = $this->getDoctrine()->getManager();

        $entityManager->persist($product);

        $entityManager->flush();

        return new Response('saved product n '.$product->getId());
    }

    /**
     * @Route("/edit-product/{id}/{label}/{price}/{quantity}", name="edit-product")
     */

    public function editProduct ($id,$label, $price, $quantity){

       

        //$product = new Produit();

        $entityManager = $this->getDoctrine()->getManager();

        $product = $entityManager->getRepository(Produit::class)->find($id);


        $product->setLabel($label);

        $product->setPrice($price);

        $product->setQuantity($quantity);

        $entityManager->flush();

        return new Response('saved product n '.$product->getId());

    }

    /**
     * @Route("/get-product/{id}", name="get-product")
     */

    public function getProduct($id)
    {

        $entityManager = $this->getDoctrine()->getManager();
         
        $products= $entityManager->getRepository(Produit::class)->getProductById($id);

        //return new Response('got product n '.$id);
        return $this->render('products/show.html.twig', array('products' => $products));
    }

    /**
     * @Route("/get-all-products", name="get-all-products")
     */

    public function getAllProducts()
    {

        $entityManager = $this->getDoctrine()->getManager();
         
        $products= $entityManager->getRepository(Produit::class)->getAllProducts();

        return $this->render('products/show.html.twig', array('products'=>$products));
    }
   
   




     
}