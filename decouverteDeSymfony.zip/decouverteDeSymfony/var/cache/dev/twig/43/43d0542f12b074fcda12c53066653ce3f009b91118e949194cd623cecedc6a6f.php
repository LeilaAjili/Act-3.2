<?php

/* base.html.twig */
class __TwigTemplate_35a788ca461558bba9038e4c3f84ff08bc8c4a644fa3eb1893a42b9f45e0624c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_574fdbb99a8b505c0286753cec7ac6422f7691dcaeb68ba64bd2097029615528 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_574fdbb99a8b505c0286753cec7ac6422f7691dcaeb68ba64bd2097029615528->enter($__internal_574fdbb99a8b505c0286753cec7ac6422f7691dcaeb68ba64bd2097029615528_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_6de32204aea5de21e96d6dee8b3c092404c487c7a8d265041d2fc9a14bd4df52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6de32204aea5de21e96d6dee8b3c092404c487c7a8d265041d2fc9a14bd4df52->enter($__internal_6de32204aea5de21e96d6dee8b3c092404c487c7a8d265041d2fc9a14bd4df52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link rel=\"stylesheet\" href=\"https://bootswatch.com/5/cosmo/bootstrap.min.css\">
        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>

        ";
        // line 13
        echo twig_include($this->env, $context, "inc/navbar.html.twig");
        echo "

        <div class=\"container\">
        ";
        // line 16
        $this->displayBlock('body', $context, $blocks);
        // line 17
        echo "        </div>
        
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js\" integrity=\"sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js\" integrity=\"sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13\" crossorigin=\"anonymous\"></script>

        ";
        // line 23
        $this->displayBlock('javascripts', $context, $blocks);
        // line 24
        echo "    </body>
</html>
";
        
        $__internal_574fdbb99a8b505c0286753cec7ac6422f7691dcaeb68ba64bd2097029615528->leave($__internal_574fdbb99a8b505c0286753cec7ac6422f7691dcaeb68ba64bd2097029615528_prof);

        
        $__internal_6de32204aea5de21e96d6dee8b3c092404c487c7a8d265041d2fc9a14bd4df52->leave($__internal_6de32204aea5de21e96d6dee8b3c092404c487c7a8d265041d2fc9a14bd4df52_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_a173900d9ce15be0d3b5dad9aee2f166c3ecbab7bccd4a6db978ea9cf4b795f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a173900d9ce15be0d3b5dad9aee2f166c3ecbab7bccd4a6db978ea9cf4b795f1->enter($__internal_a173900d9ce15be0d3b5dad9aee2f166c3ecbab7bccd4a6db978ea9cf4b795f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_625c85dbe7e41382a6a9f86dc1ab26cb3a55aeea6b4fddbcf7ed395baa5233a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_625c85dbe7e41382a6a9f86dc1ab26cb3a55aeea6b4fddbcf7ed395baa5233a4->enter($__internal_625c85dbe7e41382a6a9f86dc1ab26cb3a55aeea6b4fddbcf7ed395baa5233a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_625c85dbe7e41382a6a9f86dc1ab26cb3a55aeea6b4fddbcf7ed395baa5233a4->leave($__internal_625c85dbe7e41382a6a9f86dc1ab26cb3a55aeea6b4fddbcf7ed395baa5233a4_prof);

        
        $__internal_a173900d9ce15be0d3b5dad9aee2f166c3ecbab7bccd4a6db978ea9cf4b795f1->leave($__internal_a173900d9ce15be0d3b5dad9aee2f166c3ecbab7bccd4a6db978ea9cf4b795f1_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c10b3f82b5b6f1e729f0af31c593abc707059c22054d2ed0e076920fdaebee19 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c10b3f82b5b6f1e729f0af31c593abc707059c22054d2ed0e076920fdaebee19->enter($__internal_c10b3f82b5b6f1e729f0af31c593abc707059c22054d2ed0e076920fdaebee19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_03f8ceedbb1974147a778e4660bb5ca0120694b0d93d6ed3742673d29fb1830d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_03f8ceedbb1974147a778e4660bb5ca0120694b0d93d6ed3742673d29fb1830d->enter($__internal_03f8ceedbb1974147a778e4660bb5ca0120694b0d93d6ed3742673d29fb1830d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_03f8ceedbb1974147a778e4660bb5ca0120694b0d93d6ed3742673d29fb1830d->leave($__internal_03f8ceedbb1974147a778e4660bb5ca0120694b0d93d6ed3742673d29fb1830d_prof);

        
        $__internal_c10b3f82b5b6f1e729f0af31c593abc707059c22054d2ed0e076920fdaebee19->leave($__internal_c10b3f82b5b6f1e729f0af31c593abc707059c22054d2ed0e076920fdaebee19_prof);

    }

    // line 16
    public function block_body($context, array $blocks = array())
    {
        $__internal_713a9768f14ae95c66c95e01908e2de468dc423748dbac6394c24443abb8b629 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_713a9768f14ae95c66c95e01908e2de468dc423748dbac6394c24443abb8b629->enter($__internal_713a9768f14ae95c66c95e01908e2de468dc423748dbac6394c24443abb8b629_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_18c5469e415dd6dd1ed22e574e55b341faf0506797db01f5f5dbfd76b57df1ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18c5469e415dd6dd1ed22e574e55b341faf0506797db01f5f5dbfd76b57df1ce->enter($__internal_18c5469e415dd6dd1ed22e574e55b341faf0506797db01f5f5dbfd76b57df1ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_18c5469e415dd6dd1ed22e574e55b341faf0506797db01f5f5dbfd76b57df1ce->leave($__internal_18c5469e415dd6dd1ed22e574e55b341faf0506797db01f5f5dbfd76b57df1ce_prof);

        
        $__internal_713a9768f14ae95c66c95e01908e2de468dc423748dbac6394c24443abb8b629->leave($__internal_713a9768f14ae95c66c95e01908e2de468dc423748dbac6394c24443abb8b629_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5565f0ec1e65aae964f27ef4addfd22bc26add28cfff718c1e28b3654ab117fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5565f0ec1e65aae964f27ef4addfd22bc26add28cfff718c1e28b3654ab117fb->enter($__internal_5565f0ec1e65aae964f27ef4addfd22bc26add28cfff718c1e28b3654ab117fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_442fb8fb28b6d75a2a09543647b67c8a0f5bd073b2f101f4c7981c77f328f141 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_442fb8fb28b6d75a2a09543647b67c8a0f5bd073b2f101f4c7981c77f328f141->enter($__internal_442fb8fb28b6d75a2a09543647b67c8a0f5bd073b2f101f4c7981c77f328f141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_442fb8fb28b6d75a2a09543647b67c8a0f5bd073b2f101f4c7981c77f328f141->leave($__internal_442fb8fb28b6d75a2a09543647b67c8a0f5bd073b2f101f4c7981c77f328f141_prof);

        
        $__internal_5565f0ec1e65aae964f27ef4addfd22bc26add28cfff718c1e28b3654ab117fb->leave($__internal_5565f0ec1e65aae964f27ef4addfd22bc26add28cfff718c1e28b3654ab117fb_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 23,  116 => 16,  99 => 8,  81 => 5,  69 => 24,  67 => 23,  59 => 17,  57 => 16,  51 => 13,  43 => 9,  41 => 8,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>

        <link rel=\"stylesheet\" href=\"https://bootswatch.com/5/cosmo/bootstrap.min.css\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>

        {{ include('inc/navbar.html.twig') }}

        <div class=\"container\">
        {% block body %}{% endblock %}
        </div>
        
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js\" integrity=\"sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js\" integrity=\"sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13\" crossorigin=\"anonymous\"></script>

        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\app\\Resources\\views\\base.html.twig");
    }
}
