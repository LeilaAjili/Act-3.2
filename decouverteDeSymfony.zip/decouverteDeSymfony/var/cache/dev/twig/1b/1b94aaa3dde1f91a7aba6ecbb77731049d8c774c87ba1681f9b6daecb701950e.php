<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_057fd96f4c4f70718795b3438c121e5106fdf92611d5b2d0ecf51ec91f78baed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd714b7555a0914e86126095816c19b5737ec83452b94396b819603b4c8a0946 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd714b7555a0914e86126095816c19b5737ec83452b94396b819603b4c8a0946->enter($__internal_dd714b7555a0914e86126095816c19b5737ec83452b94396b819603b4c8a0946_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_956d8dc560094216b4d93bebd3c21ded404c9354ba26622b1bcafb2835087523 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_956d8dc560094216b4d93bebd3c21ded404c9354ba26622b1bcafb2835087523->enter($__internal_956d8dc560094216b4d93bebd3c21ded404c9354ba26622b1bcafb2835087523_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_dd714b7555a0914e86126095816c19b5737ec83452b94396b819603b4c8a0946->leave($__internal_dd714b7555a0914e86126095816c19b5737ec83452b94396b819603b4c8a0946_prof);

        
        $__internal_956d8dc560094216b4d93bebd3c21ded404c9354ba26622b1bcafb2835087523->leave($__internal_956d8dc560094216b4d93bebd3c21ded404c9354ba26622b1bcafb2835087523_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
