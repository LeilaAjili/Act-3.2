<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_6f31eb275bcfe2ff284ee4ce5a897064070e559597f9dbd071c2fb7b99842baf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b9bd1c594843a1d9503e33500f04e68a6496b07f0cf8ef70d8516cdba1fe0d40 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b9bd1c594843a1d9503e33500f04e68a6496b07f0cf8ef70d8516cdba1fe0d40->enter($__internal_b9bd1c594843a1d9503e33500f04e68a6496b07f0cf8ef70d8516cdba1fe0d40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_83b4b96c2bb38e6037119c9b84d41e90b29660b1cdfd13fb8a3aab45d429a90f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83b4b96c2bb38e6037119c9b84d41e90b29660b1cdfd13fb8a3aab45d429a90f->enter($__internal_83b4b96c2bb38e6037119c9b84d41e90b29660b1cdfd13fb8a3aab45d429a90f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_b9bd1c594843a1d9503e33500f04e68a6496b07f0cf8ef70d8516cdba1fe0d40->leave($__internal_b9bd1c594843a1d9503e33500f04e68a6496b07f0cf8ef70d8516cdba1fe0d40_prof);

        
        $__internal_83b4b96c2bb38e6037119c9b84d41e90b29660b1cdfd13fb8a3aab45d429a90f->leave($__internal_83b4b96c2bb38e6037119c9b84d41e90b29660b1cdfd13fb8a3aab45d429a90f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
