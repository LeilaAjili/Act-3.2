<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_4636f147e5f61754611d1e3378dfab98d1aae296d339b07bbe1163ced9283ca8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_010f43c0c9962c5bdb945f576cebe5fcf49b01e66387b4a2b7c1ad8a42f18d59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_010f43c0c9962c5bdb945f576cebe5fcf49b01e66387b4a2b7c1ad8a42f18d59->enter($__internal_010f43c0c9962c5bdb945f576cebe5fcf49b01e66387b4a2b7c1ad8a42f18d59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_7af007368082f04ed6471e66537e361d8dd3a9eda8a32002325aa893febc2604 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7af007368082f04ed6471e66537e361d8dd3a9eda8a32002325aa893febc2604->enter($__internal_7af007368082f04ed6471e66537e361d8dd3a9eda8a32002325aa893febc2604_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_010f43c0c9962c5bdb945f576cebe5fcf49b01e66387b4a2b7c1ad8a42f18d59->leave($__internal_010f43c0c9962c5bdb945f576cebe5fcf49b01e66387b4a2b7c1ad8a42f18d59_prof);

        
        $__internal_7af007368082f04ed6471e66537e361d8dd3a9eda8a32002325aa893febc2604->leave($__internal_7af007368082f04ed6471e66537e361d8dd3a9eda8a32002325aa893febc2604_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
