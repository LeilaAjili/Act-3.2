<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_8dc19400dffc6207b2952c9d3259751d3466efed668a62b0dc7966d48142f2d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8fa17c4cf4262b89ebfc30b7e85fe359615c17fd5219ad46595c8aa2ebe5b42 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a8fa17c4cf4262b89ebfc30b7e85fe359615c17fd5219ad46595c8aa2ebe5b42->enter($__internal_a8fa17c4cf4262b89ebfc30b7e85fe359615c17fd5219ad46595c8aa2ebe5b42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_377b92d069e275545b0eef7c722b3dac969d8b6c6b00bc230d3d6002b830fe2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_377b92d069e275545b0eef7c722b3dac969d8b6c6b00bc230d3d6002b830fe2f->enter($__internal_377b92d069e275545b0eef7c722b3dac969d8b6c6b00bc230d3d6002b830fe2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_a8fa17c4cf4262b89ebfc30b7e85fe359615c17fd5219ad46595c8aa2ebe5b42->leave($__internal_a8fa17c4cf4262b89ebfc30b7e85fe359615c17fd5219ad46595c8aa2ebe5b42_prof);

        
        $__internal_377b92d069e275545b0eef7c722b3dac969d8b6c6b00bc230d3d6002b830fe2f->leave($__internal_377b92d069e275545b0eef7c722b3dac969d8b6c6b00bc230d3d6002b830fe2f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
