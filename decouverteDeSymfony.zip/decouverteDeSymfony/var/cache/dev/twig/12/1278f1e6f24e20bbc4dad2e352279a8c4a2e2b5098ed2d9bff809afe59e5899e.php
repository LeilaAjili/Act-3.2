<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_c8285102c09d5fce2d96c802385800449930b41363c746a9bc6777ef69ab3bd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c210308b0776670c50f2ab700c1ada49460e609a1934db1b725fc6b8f31f91a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7c210308b0776670c50f2ab700c1ada49460e609a1934db1b725fc6b8f31f91a->enter($__internal_7c210308b0776670c50f2ab700c1ada49460e609a1934db1b725fc6b8f31f91a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_1382a64804c2de99acde91d1061667febdaba7bc674351fb2e46709f1c594143 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1382a64804c2de99acde91d1061667febdaba7bc674351fb2e46709f1c594143->enter($__internal_1382a64804c2de99acde91d1061667febdaba7bc674351fb2e46709f1c594143_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_7c210308b0776670c50f2ab700c1ada49460e609a1934db1b725fc6b8f31f91a->leave($__internal_7c210308b0776670c50f2ab700c1ada49460e609a1934db1b725fc6b8f31f91a_prof);

        
        $__internal_1382a64804c2de99acde91d1061667febdaba7bc674351fb2e46709f1c594143->leave($__internal_1382a64804c2de99acde91d1061667febdaba7bc674351fb2e46709f1c594143_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.css.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
