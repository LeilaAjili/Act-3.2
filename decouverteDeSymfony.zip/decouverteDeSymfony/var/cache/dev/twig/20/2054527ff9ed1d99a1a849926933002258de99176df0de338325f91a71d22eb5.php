<?php

/* bootstrap_3_layout.html.twig */
class __TwigTemplate_5526634d00e1b3c0fe3d49e51a5d49e6c66d009014c14d98275452aad1d77274 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_base_layout.html.twig", "bootstrap_3_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_base_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'button_widget' => array($this, 'block_button_widget'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'form_label' => array($this, 'block_form_label'),
                'choice_label' => array($this, 'block_choice_label'),
                'checkbox_label' => array($this, 'block_checkbox_label'),
                'radio_label' => array($this, 'block_radio_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'choice_row' => array($this, 'block_choice_row'),
                'date_row' => array($this, 'block_date_row'),
                'time_row' => array($this, 'block_time_row'),
                'datetime_row' => array($this, 'block_datetime_row'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
                'radio_row' => array($this, 'block_radio_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f75c0ce222c51b3ada85fd0d503b735835c4396662554c234cc817c3da1be973 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f75c0ce222c51b3ada85fd0d503b735835c4396662554c234cc817c3da1be973->enter($__internal_f75c0ce222c51b3ada85fd0d503b735835c4396662554c234cc817c3da1be973_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        $__internal_612bdc43ef3a520149777a6070d99bcf1dc0f8a60f125fa1f20eebd80fd38094 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_612bdc43ef3a520149777a6070d99bcf1dc0f8a60f125fa1f20eebd80fd38094->enter($__internal_612bdc43ef3a520149777a6070d99bcf1dc0f8a60f125fa1f20eebd80fd38094_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 11
        echo "
";
        // line 12
        $this->displayBlock('button_widget', $context, $blocks);
        // line 16
        echo "
";
        // line 17
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 27
        echo "
";
        // line 28
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 38
        echo "
";
        // line 40
        echo "
";
        // line 41
        $this->displayBlock('form_label', $context, $blocks);
        // line 45
        echo "
";
        // line 46
        $this->displayBlock('choice_label', $context, $blocks);
        // line 51
        echo "
";
        // line 52
        $this->displayBlock('checkbox_label', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('radio_label', $context, $blocks);
        // line 63
        echo "
";
        // line 64
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 88
        echo "
";
        // line 90
        echo "
";
        // line 91
        $this->displayBlock('form_row', $context, $blocks);
        // line 98
        echo "
";
        // line 99
        $this->displayBlock('button_row', $context, $blocks);
        // line 104
        echo "
";
        // line 105
        $this->displayBlock('choice_row', $context, $blocks);
        // line 109
        echo "
";
        // line 110
        $this->displayBlock('date_row', $context, $blocks);
        // line 114
        echo "
";
        // line 115
        $this->displayBlock('time_row', $context, $blocks);
        // line 119
        echo "
";
        // line 120
        $this->displayBlock('datetime_row', $context, $blocks);
        // line 124
        echo "
";
        // line 125
        $this->displayBlock('checkbox_row', $context, $blocks);
        // line 131
        echo "
";
        // line 132
        $this->displayBlock('radio_row', $context, $blocks);
        // line 138
        echo "
";
        // line 140
        echo "
";
        // line 141
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_f75c0ce222c51b3ada85fd0d503b735835c4396662554c234cc817c3da1be973->leave($__internal_f75c0ce222c51b3ada85fd0d503b735835c4396662554c234cc817c3da1be973_prof);

        
        $__internal_612bdc43ef3a520149777a6070d99bcf1dc0f8a60f125fa1f20eebd80fd38094->leave($__internal_612bdc43ef3a520149777a6070d99bcf1dc0f8a60f125fa1f20eebd80fd38094_prof);

    }

    // line 5
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_0f90af1885dfe3852cbea6871df65f0a2976b63ff12751e6fa4f77b3f0ff123d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f90af1885dfe3852cbea6871df65f0a2976b63ff12751e6fa4f77b3f0ff123d->enter($__internal_0f90af1885dfe3852cbea6871df65f0a2976b63ff12751e6fa4f77b3f0ff123d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_c72a4c250aa54f7fbfbd1e93743db26d6bc0a5caa68248353fd27493961aebd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c72a4c250aa54f7fbfbd1e93743db26d6bc0a5caa68248353fd27493961aebd6->enter($__internal_c72a4c250aa54f7fbfbd1e93743db26d6bc0a5caa68248353fd27493961aebd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 6
        if (( !array_key_exists("type", $context) || !twig_in_filter(($context["type"] ?? $this->getContext($context, "type")), array(0 => "file", 1 => "hidden")))) {
            // line 7
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        }
        // line 9
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_c72a4c250aa54f7fbfbd1e93743db26d6bc0a5caa68248353fd27493961aebd6->leave($__internal_c72a4c250aa54f7fbfbd1e93743db26d6bc0a5caa68248353fd27493961aebd6_prof);

        
        $__internal_0f90af1885dfe3852cbea6871df65f0a2976b63ff12751e6fa4f77b3f0ff123d->leave($__internal_0f90af1885dfe3852cbea6871df65f0a2976b63ff12751e6fa4f77b3f0ff123d_prof);

    }

    // line 12
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_5e43993f6c8d43c74c13cf325226b2f47e579541e7d50c9a6461a8c23d88130d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e43993f6c8d43c74c13cf325226b2f47e579541e7d50c9a6461a8c23d88130d->enter($__internal_5e43993f6c8d43c74c13cf325226b2f47e579541e7d50c9a6461a8c23d88130d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_2026f163837697b1b33bb3c744a03fc32c1fb75c15be8ff2ab93d867f3f4f9aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2026f163837697b1b33bb3c744a03fc32c1fb75c15be8ff2ab93d867f3f4f9aa->enter($__internal_2026f163837697b1b33bb3c744a03fc32c1fb75c15be8ff2ab93d867f3f4f9aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 13
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-default")) : ("btn-default")) . " btn"))));
        // line 14
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_2026f163837697b1b33bb3c744a03fc32c1fb75c15be8ff2ab93d867f3f4f9aa->leave($__internal_2026f163837697b1b33bb3c744a03fc32c1fb75c15be8ff2ab93d867f3f4f9aa_prof);

        
        $__internal_5e43993f6c8d43c74c13cf325226b2f47e579541e7d50c9a6461a8c23d88130d->leave($__internal_5e43993f6c8d43c74c13cf325226b2f47e579541e7d50c9a6461a8c23d88130d_prof);

    }

    // line 17
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_1bfd2a0740a3f93a1d785d01c5a79d7bd377f3114e49c2b60c9515f6b412176c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1bfd2a0740a3f93a1d785d01c5a79d7bd377f3114e49c2b60c9515f6b412176c->enter($__internal_1bfd2a0740a3f93a1d785d01c5a79d7bd377f3114e49c2b60c9515f6b412176c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_16c2a684166ed6b42a97e4177434a09719b7747be8371f7c20d06773217b9781 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16c2a684166ed6b42a97e4177434a09719b7747be8371f7c20d06773217b9781->enter($__internal_16c2a684166ed6b42a97e4177434a09719b7747be8371f7c20d06773217b9781_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 18
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 19
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 20
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 22
            echo "<div class=\"checkbox\">";
            // line 23
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 24
            echo "</div>";
        }
        
        $__internal_16c2a684166ed6b42a97e4177434a09719b7747be8371f7c20d06773217b9781->leave($__internal_16c2a684166ed6b42a97e4177434a09719b7747be8371f7c20d06773217b9781_prof);

        
        $__internal_1bfd2a0740a3f93a1d785d01c5a79d7bd377f3114e49c2b60c9515f6b412176c->leave($__internal_1bfd2a0740a3f93a1d785d01c5a79d7bd377f3114e49c2b60c9515f6b412176c_prof);

    }

    // line 28
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_aba8e3e50ea53ef6b6ce6375bdfd9d5816ce18547dcf64b552741d99bd84f9ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aba8e3e50ea53ef6b6ce6375bdfd9d5816ce18547dcf64b552741d99bd84f9ae->enter($__internal_aba8e3e50ea53ef6b6ce6375bdfd9d5816ce18547dcf64b552741d99bd84f9ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_110f8e98dd3c8cab2199fe193a00d5d3c6de3d32f700daabdf13897d6474dac3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_110f8e98dd3c8cab2199fe193a00d5d3c6de3d32f700daabdf13897d6474dac3->enter($__internal_110f8e98dd3c8cab2199fe193a00d5d3c6de3d32f700daabdf13897d6474dac3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 29
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 30
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 31
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 33
            echo "<div class=\"radio\">";
            // line 34
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 35
            echo "</div>";
        }
        
        $__internal_110f8e98dd3c8cab2199fe193a00d5d3c6de3d32f700daabdf13897d6474dac3->leave($__internal_110f8e98dd3c8cab2199fe193a00d5d3c6de3d32f700daabdf13897d6474dac3_prof);

        
        $__internal_aba8e3e50ea53ef6b6ce6375bdfd9d5816ce18547dcf64b552741d99bd84f9ae->leave($__internal_aba8e3e50ea53ef6b6ce6375bdfd9d5816ce18547dcf64b552741d99bd84f9ae_prof);

    }

    // line 41
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_cb93a0f8f67055cfd833fcafc61a0beb14d923b9a9c646f8e08faa5903e191ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb93a0f8f67055cfd833fcafc61a0beb14d923b9a9c646f8e08faa5903e191ad->enter($__internal_cb93a0f8f67055cfd833fcafc61a0beb14d923b9a9c646f8e08faa5903e191ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_d65b26bfb7cbc1aece2e0f5b6028fcb9f63aacfd905353c808fa8032f230d97a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d65b26bfb7cbc1aece2e0f5b6028fcb9f63aacfd905353c808fa8032f230d97a->enter($__internal_d65b26bfb7cbc1aece2e0f5b6028fcb9f63aacfd905353c808fa8032f230d97a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 42
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " control-label"))));
        // line 43
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_d65b26bfb7cbc1aece2e0f5b6028fcb9f63aacfd905353c808fa8032f230d97a->leave($__internal_d65b26bfb7cbc1aece2e0f5b6028fcb9f63aacfd905353c808fa8032f230d97a_prof);

        
        $__internal_cb93a0f8f67055cfd833fcafc61a0beb14d923b9a9c646f8e08faa5903e191ad->leave($__internal_cb93a0f8f67055cfd833fcafc61a0beb14d923b9a9c646f8e08faa5903e191ad_prof);

    }

    // line 46
    public function block_choice_label($context, array $blocks = array())
    {
        $__internal_c54e0618556a3f60f18a670e3d0293f4dbb044be2c4cae514933a205c09a585d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c54e0618556a3f60f18a670e3d0293f4dbb044be2c4cae514933a205c09a585d->enter($__internal_c54e0618556a3f60f18a670e3d0293f4dbb044be2c4cae514933a205c09a585d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        $__internal_5c818dd8fcf465e4369248f3b36b9489ecd417de723ded2b4a9f9f792c75c8bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c818dd8fcf465e4369248f3b36b9489ecd417de723ded2b4a9f9f792c75c8bd->enter($__internal_5c818dd8fcf465e4369248f3b36b9489ecd417de723ded2b4a9f9f792c75c8bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        // line 48
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(twig_replace_filter((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), array("checkbox-inline" => "", "radio-inline" => "")))));
        // line 49
        $this->displayBlock("form_label", $context, $blocks);
        
        $__internal_5c818dd8fcf465e4369248f3b36b9489ecd417de723ded2b4a9f9f792c75c8bd->leave($__internal_5c818dd8fcf465e4369248f3b36b9489ecd417de723ded2b4a9f9f792c75c8bd_prof);

        
        $__internal_c54e0618556a3f60f18a670e3d0293f4dbb044be2c4cae514933a205c09a585d->leave($__internal_c54e0618556a3f60f18a670e3d0293f4dbb044be2c4cae514933a205c09a585d_prof);

    }

    // line 52
    public function block_checkbox_label($context, array $blocks = array())
    {
        $__internal_3df9fa23c70a70a0c301e02b817483e9a88839d8130a59d623cc0f709b10665c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3df9fa23c70a70a0c301e02b817483e9a88839d8130a59d623cc0f709b10665c->enter($__internal_3df9fa23c70a70a0c301e02b817483e9a88839d8130a59d623cc0f709b10665c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        $__internal_350634e3ad8f68bc53fc33a1e015e5e20fbfcefeadbe22f9ef4f1aabe84ea256 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_350634e3ad8f68bc53fc33a1e015e5e20fbfcefeadbe22f9ef4f1aabe84ea256->enter($__internal_350634e3ad8f68bc53fc33a1e015e5e20fbfcefeadbe22f9ef4f1aabe84ea256_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        // line 53
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 55
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_350634e3ad8f68bc53fc33a1e015e5e20fbfcefeadbe22f9ef4f1aabe84ea256->leave($__internal_350634e3ad8f68bc53fc33a1e015e5e20fbfcefeadbe22f9ef4f1aabe84ea256_prof);

        
        $__internal_3df9fa23c70a70a0c301e02b817483e9a88839d8130a59d623cc0f709b10665c->leave($__internal_3df9fa23c70a70a0c301e02b817483e9a88839d8130a59d623cc0f709b10665c_prof);

    }

    // line 58
    public function block_radio_label($context, array $blocks = array())
    {
        $__internal_6006f9dc2815cc320a9473ab0839b85c429245bb00b57fea71e1366103ed665d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6006f9dc2815cc320a9473ab0839b85c429245bb00b57fea71e1366103ed665d->enter($__internal_6006f9dc2815cc320a9473ab0839b85c429245bb00b57fea71e1366103ed665d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        $__internal_5bc646767fa236c0949f76c4669f761d1c95f21780510a6042837a45495b5dc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5bc646767fa236c0949f76c4669f761d1c95f21780510a6042837a45495b5dc9->enter($__internal_5bc646767fa236c0949f76c4669f761d1c95f21780510a6042837a45495b5dc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        // line 59
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 61
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_5bc646767fa236c0949f76c4669f761d1c95f21780510a6042837a45495b5dc9->leave($__internal_5bc646767fa236c0949f76c4669f761d1c95f21780510a6042837a45495b5dc9_prof);

        
        $__internal_6006f9dc2815cc320a9473ab0839b85c429245bb00b57fea71e1366103ed665d->leave($__internal_6006f9dc2815cc320a9473ab0839b85c429245bb00b57fea71e1366103ed665d_prof);

    }

    // line 64
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_f408d1575e2aefd69e41c94c9615758e64f5c4f01c798611a2d378eb93f2993f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f408d1575e2aefd69e41c94c9615758e64f5c4f01c798611a2d378eb93f2993f->enter($__internal_f408d1575e2aefd69e41c94c9615758e64f5c4f01c798611a2d378eb93f2993f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_4e34dd19d59dac10c5ddd923259a3ac84080a443d7a3426d94a15adffa0f1f1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e34dd19d59dac10c5ddd923259a3ac84080a443d7a3426d94a15adffa0f1f1a->enter($__internal_4e34dd19d59dac10c5ddd923259a3ac84080a443d7a3426d94a15adffa0f1f1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 66
        if (array_key_exists("widget", $context)) {
            // line 67
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 68
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
            }
            // line 70
            if (array_key_exists("parent_label_class", $context)) {
                // line 71
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
            }
            // line 73
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 74
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 75
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 76
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 77
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 80
                    $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 83
            echo "<label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 84
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 85
            echo "</label>";
        }
        
        $__internal_4e34dd19d59dac10c5ddd923259a3ac84080a443d7a3426d94a15adffa0f1f1a->leave($__internal_4e34dd19d59dac10c5ddd923259a3ac84080a443d7a3426d94a15adffa0f1f1a_prof);

        
        $__internal_f408d1575e2aefd69e41c94c9615758e64f5c4f01c798611a2d378eb93f2993f->leave($__internal_f408d1575e2aefd69e41c94c9615758e64f5c4f01c798611a2d378eb93f2993f_prof);

    }

    // line 91
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_fa9e384500d8ba229d91f155428177df6ea1909ab07dd9bef1aff1c212336d7c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa9e384500d8ba229d91f155428177df6ea1909ab07dd9bef1aff1c212336d7c->enter($__internal_fa9e384500d8ba229d91f155428177df6ea1909ab07dd9bef1aff1c212336d7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_9357ac887ae7d2d1d5b0ca3ec984b8cbf0dd21550c5f9b962ce35afb52f1cfb5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9357ac887ae7d2d1d5b0ca3ec984b8cbf0dd21550c5f9b962ce35afb52f1cfb5->enter($__internal_9357ac887ae7d2d1d5b0ca3ec984b8cbf0dd21550c5f9b962ce35afb52f1cfb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 92
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 93
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 94
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 95
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 96
        echo "</div>";
        
        $__internal_9357ac887ae7d2d1d5b0ca3ec984b8cbf0dd21550c5f9b962ce35afb52f1cfb5->leave($__internal_9357ac887ae7d2d1d5b0ca3ec984b8cbf0dd21550c5f9b962ce35afb52f1cfb5_prof);

        
        $__internal_fa9e384500d8ba229d91f155428177df6ea1909ab07dd9bef1aff1c212336d7c->leave($__internal_fa9e384500d8ba229d91f155428177df6ea1909ab07dd9bef1aff1c212336d7c_prof);

    }

    // line 99
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_1ac925fe10124846799912a5289eea56f53937fce0e3932fe0a4d840c7b5f3c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1ac925fe10124846799912a5289eea56f53937fce0e3932fe0a4d840c7b5f3c3->enter($__internal_1ac925fe10124846799912a5289eea56f53937fce0e3932fe0a4d840c7b5f3c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_3406720a10a33e9f62b950a071bffd4c5a48b9fc10a20ef111387967ecdf7224 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3406720a10a33e9f62b950a071bffd4c5a48b9fc10a20ef111387967ecdf7224->enter($__internal_3406720a10a33e9f62b950a071bffd4c5a48b9fc10a20ef111387967ecdf7224_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 100
        echo "<div class=\"form-group\">";
        // line 101
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 102
        echo "</div>";
        
        $__internal_3406720a10a33e9f62b950a071bffd4c5a48b9fc10a20ef111387967ecdf7224->leave($__internal_3406720a10a33e9f62b950a071bffd4c5a48b9fc10a20ef111387967ecdf7224_prof);

        
        $__internal_1ac925fe10124846799912a5289eea56f53937fce0e3932fe0a4d840c7b5f3c3->leave($__internal_1ac925fe10124846799912a5289eea56f53937fce0e3932fe0a4d840c7b5f3c3_prof);

    }

    // line 105
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_a228be5b0f1ce58d3f411a37f0d025f14d7490c296b33c7b89513928d020e226 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a228be5b0f1ce58d3f411a37f0d025f14d7490c296b33c7b89513928d020e226->enter($__internal_a228be5b0f1ce58d3f411a37f0d025f14d7490c296b33c7b89513928d020e226_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        $__internal_12f9cb433fd431e44b11476e77cb607c768f6dfb4fe693537f78727d4e3cf24d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12f9cb433fd431e44b11476e77cb607c768f6dfb4fe693537f78727d4e3cf24d->enter($__internal_12f9cb433fd431e44b11476e77cb607c768f6dfb4fe693537f78727d4e3cf24d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 106
        $context["force_error"] = true;
        // line 107
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_12f9cb433fd431e44b11476e77cb607c768f6dfb4fe693537f78727d4e3cf24d->leave($__internal_12f9cb433fd431e44b11476e77cb607c768f6dfb4fe693537f78727d4e3cf24d_prof);

        
        $__internal_a228be5b0f1ce58d3f411a37f0d025f14d7490c296b33c7b89513928d020e226->leave($__internal_a228be5b0f1ce58d3f411a37f0d025f14d7490c296b33c7b89513928d020e226_prof);

    }

    // line 110
    public function block_date_row($context, array $blocks = array())
    {
        $__internal_72fe98954ee531bc4d132f568c68b0d07d7988fa734cd75e03c25e7684f49618 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_72fe98954ee531bc4d132f568c68b0d07d7988fa734cd75e03c25e7684f49618->enter($__internal_72fe98954ee531bc4d132f568c68b0d07d7988fa734cd75e03c25e7684f49618_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        $__internal_380cdd9b5e776e5deb5465729c3be39f5f2bcc511079a0854e1cca544eb932a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_380cdd9b5e776e5deb5465729c3be39f5f2bcc511079a0854e1cca544eb932a7->enter($__internal_380cdd9b5e776e5deb5465729c3be39f5f2bcc511079a0854e1cca544eb932a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        // line 111
        $context["force_error"] = true;
        // line 112
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_380cdd9b5e776e5deb5465729c3be39f5f2bcc511079a0854e1cca544eb932a7->leave($__internal_380cdd9b5e776e5deb5465729c3be39f5f2bcc511079a0854e1cca544eb932a7_prof);

        
        $__internal_72fe98954ee531bc4d132f568c68b0d07d7988fa734cd75e03c25e7684f49618->leave($__internal_72fe98954ee531bc4d132f568c68b0d07d7988fa734cd75e03c25e7684f49618_prof);

    }

    // line 115
    public function block_time_row($context, array $blocks = array())
    {
        $__internal_b3d833621f2e56c848fcc6068b3e3afa2b92291cfea59073153889ff23f1d11b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3d833621f2e56c848fcc6068b3e3afa2b92291cfea59073153889ff23f1d11b->enter($__internal_b3d833621f2e56c848fcc6068b3e3afa2b92291cfea59073153889ff23f1d11b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        $__internal_07cbeac2d6797d863554f17c024ff12e5ca653a5ae618073ab03f3db4272b250 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07cbeac2d6797d863554f17c024ff12e5ca653a5ae618073ab03f3db4272b250->enter($__internal_07cbeac2d6797d863554f17c024ff12e5ca653a5ae618073ab03f3db4272b250_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        // line 116
        $context["force_error"] = true;
        // line 117
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_07cbeac2d6797d863554f17c024ff12e5ca653a5ae618073ab03f3db4272b250->leave($__internal_07cbeac2d6797d863554f17c024ff12e5ca653a5ae618073ab03f3db4272b250_prof);

        
        $__internal_b3d833621f2e56c848fcc6068b3e3afa2b92291cfea59073153889ff23f1d11b->leave($__internal_b3d833621f2e56c848fcc6068b3e3afa2b92291cfea59073153889ff23f1d11b_prof);

    }

    // line 120
    public function block_datetime_row($context, array $blocks = array())
    {
        $__internal_787ca4749ec34f787a650a92068d57487d3a32ed27e96f535a4d35fb5f8cdbf0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_787ca4749ec34f787a650a92068d57487d3a32ed27e96f535a4d35fb5f8cdbf0->enter($__internal_787ca4749ec34f787a650a92068d57487d3a32ed27e96f535a4d35fb5f8cdbf0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        $__internal_ebf1b98e5a3a8ef30e362a4bd022cd51cd40feb793fb0a79bd191ba57306cef6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebf1b98e5a3a8ef30e362a4bd022cd51cd40feb793fb0a79bd191ba57306cef6->enter($__internal_ebf1b98e5a3a8ef30e362a4bd022cd51cd40feb793fb0a79bd191ba57306cef6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        // line 121
        $context["force_error"] = true;
        // line 122
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_ebf1b98e5a3a8ef30e362a4bd022cd51cd40feb793fb0a79bd191ba57306cef6->leave($__internal_ebf1b98e5a3a8ef30e362a4bd022cd51cd40feb793fb0a79bd191ba57306cef6_prof);

        
        $__internal_787ca4749ec34f787a650a92068d57487d3a32ed27e96f535a4d35fb5f8cdbf0->leave($__internal_787ca4749ec34f787a650a92068d57487d3a32ed27e96f535a4d35fb5f8cdbf0_prof);

    }

    // line 125
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_3a187de086289b4ccd1d766ccc97dbe1718c8fad8711abb2114a2cbd011f8f96 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a187de086289b4ccd1d766ccc97dbe1718c8fad8711abb2114a2cbd011f8f96->enter($__internal_3a187de086289b4ccd1d766ccc97dbe1718c8fad8711abb2114a2cbd011f8f96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_1a0845fdc6eca080c5e4f0303d853e2a0755ec1d699f0482533f716bedfbd71f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a0845fdc6eca080c5e4f0303d853e2a0755ec1d699f0482533f716bedfbd71f->enter($__internal_1a0845fdc6eca080c5e4f0303d853e2a0755ec1d699f0482533f716bedfbd71f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 126
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 127
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 128
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 129
        echo "</div>";
        
        $__internal_1a0845fdc6eca080c5e4f0303d853e2a0755ec1d699f0482533f716bedfbd71f->leave($__internal_1a0845fdc6eca080c5e4f0303d853e2a0755ec1d699f0482533f716bedfbd71f_prof);

        
        $__internal_3a187de086289b4ccd1d766ccc97dbe1718c8fad8711abb2114a2cbd011f8f96->leave($__internal_3a187de086289b4ccd1d766ccc97dbe1718c8fad8711abb2114a2cbd011f8f96_prof);

    }

    // line 132
    public function block_radio_row($context, array $blocks = array())
    {
        $__internal_0ee2947e18471f5be91b7b2224b9f9229171b15d0ac96125447f5ebf23608870 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ee2947e18471f5be91b7b2224b9f9229171b15d0ac96125447f5ebf23608870->enter($__internal_0ee2947e18471f5be91b7b2224b9f9229171b15d0ac96125447f5ebf23608870_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        $__internal_c80af632d8bf1f89b710de4cbd19d3e1ee94241eb25662691c5a6378e355ae17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c80af632d8bf1f89b710de4cbd19d3e1ee94241eb25662691c5a6378e355ae17->enter($__internal_c80af632d8bf1f89b710de4cbd19d3e1ee94241eb25662691c5a6378e355ae17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        // line 133
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 134
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 135
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 136
        echo "</div>";
        
        $__internal_c80af632d8bf1f89b710de4cbd19d3e1ee94241eb25662691c5a6378e355ae17->leave($__internal_c80af632d8bf1f89b710de4cbd19d3e1ee94241eb25662691c5a6378e355ae17_prof);

        
        $__internal_0ee2947e18471f5be91b7b2224b9f9229171b15d0ac96125447f5ebf23608870->leave($__internal_0ee2947e18471f5be91b7b2224b9f9229171b15d0ac96125447f5ebf23608870_prof);

    }

    // line 141
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_096464033dd27a13613a6fdfe159ae479d2a3259a52aacfa1e8b93f46500066f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_096464033dd27a13613a6fdfe159ae479d2a3259a52aacfa1e8b93f46500066f->enter($__internal_096464033dd27a13613a6fdfe159ae479d2a3259a52aacfa1e8b93f46500066f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_51a0c746b1c6b210a84d4c612ed1b13d6921df56619faccdf94afd537138e70c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51a0c746b1c6b210a84d4c612ed1b13d6921df56619faccdf94afd537138e70c->enter($__internal_51a0c746b1c6b210a84d4c612ed1b13d6921df56619faccdf94afd537138e70c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 142
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 143
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 144
            echo "    <ul class=\"list-unstyled\">";
            // line 145
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 146
                echo "<li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 148
            echo "</ul>
    ";
            // line 149
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_51a0c746b1c6b210a84d4c612ed1b13d6921df56619faccdf94afd537138e70c->leave($__internal_51a0c746b1c6b210a84d4c612ed1b13d6921df56619faccdf94afd537138e70c_prof);

        
        $__internal_096464033dd27a13613a6fdfe159ae479d2a3259a52aacfa1e8b93f46500066f->leave($__internal_096464033dd27a13613a6fdfe159ae479d2a3259a52aacfa1e8b93f46500066f_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  650 => 149,  647 => 148,  639 => 146,  635 => 145,  633 => 144,  627 => 143,  625 => 142,  616 => 141,  606 => 136,  604 => 135,  602 => 134,  596 => 133,  587 => 132,  577 => 129,  575 => 128,  573 => 127,  567 => 126,  558 => 125,  548 => 122,  546 => 121,  537 => 120,  527 => 117,  525 => 116,  516 => 115,  506 => 112,  504 => 111,  495 => 110,  485 => 107,  483 => 106,  474 => 105,  464 => 102,  462 => 101,  460 => 100,  451 => 99,  441 => 96,  439 => 95,  437 => 94,  435 => 93,  429 => 92,  420 => 91,  409 => 85,  405 => 84,  390 => 83,  386 => 80,  383 => 77,  382 => 76,  381 => 75,  379 => 74,  377 => 73,  374 => 71,  372 => 70,  369 => 68,  367 => 67,  365 => 66,  356 => 64,  346 => 61,  344 => 59,  335 => 58,  325 => 55,  323 => 53,  314 => 52,  304 => 49,  302 => 48,  293 => 46,  283 => 43,  281 => 42,  272 => 41,  261 => 35,  259 => 34,  257 => 33,  254 => 31,  252 => 30,  250 => 29,  241 => 28,  230 => 24,  228 => 23,  226 => 22,  223 => 20,  221 => 19,  219 => 18,  210 => 17,  200 => 14,  198 => 13,  189 => 12,  179 => 9,  176 => 7,  174 => 6,  165 => 5,  155 => 141,  152 => 140,  149 => 138,  147 => 132,  144 => 131,  142 => 125,  139 => 124,  137 => 120,  134 => 119,  132 => 115,  129 => 114,  127 => 110,  124 => 109,  122 => 105,  119 => 104,  117 => 99,  114 => 98,  112 => 91,  109 => 90,  106 => 88,  104 => 64,  101 => 63,  99 => 58,  96 => 57,  94 => 52,  91 => 51,  89 => 46,  86 => 45,  84 => 41,  81 => 40,  78 => 38,  76 => 28,  73 => 27,  71 => 17,  68 => 16,  66 => 12,  63 => 11,  61 => 5,  58 => 4,  55 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_base_layout.html.twig\" %}

{# Widgets #}

{% block form_widget_simple -%}
    {% if type is not defined or type not in ['file', 'hidden'] %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{% block button_widget -%}
    {%- set attr = attr|merge({class: (attr.class|default('btn-default') ~ ' btn')|trim}) -%}
    {{- parent() -}}
{%- endblock button_widget %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"checkbox\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {%- if 'radio-inline' in parent_label_class -%}
        {{- form_label(form, null, { widget: parent() }) -}}
    {%- else -%}
        <div class=\"radio\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock radio_widget %}

{# Labels #}

{% block form_label -%}
    {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' control-label')|trim}) -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block choice_label -%}
    {# remove the checkbox-inline and radio-inline class, it's only useful for embed labels #}
    {%- set label_attr = label_attr|merge({class: label_attr.class|default('')|replace({'checkbox-inline': '', 'radio-inline': ''})|trim}) -%}
    {{- block('form_label') -}}
{% endblock %}

{% block checkbox_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock checkbox_label %}

{% block radio_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock radio_label %}

{% block checkbox_radio_label -%}
    {# Do not display the label if widget is not defined in order to prevent double label rendering #}
    {%- if widget is defined -%}
        {%- if required -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) -%}
        {%- endif -%}
        {%- if parent_label_class is defined -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) -%}
        {%- endif -%}
        {%- if label is not same as(false) and label is empty -%}
            {%- if label_format is not empty -%}
                {%- set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) -%}
            {%- else -%}
                {% set label = name|humanize %}
            {%- endif -%}
        {%- endif -%}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {%- endif -%}
{%- endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock form_row %}

{% block button_row -%}
    <div class=\"form-group\">
        {{- form_widget(form) -}}
    </div>
{%- endblock button_row %}

{% block choice_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock choice_row %}

{% block date_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock date_row %}

{% block time_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock time_row %}

{% block datetime_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock datetime_row %}

{% block checkbox_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock checkbox_row %}

{% block radio_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock radio_row %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
    {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
    <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            <li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> {{ error.message }}</li>
        {%- endfor -%}
    </ul>
    {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_3_layout.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_3_layout.html.twig");
    }
}
