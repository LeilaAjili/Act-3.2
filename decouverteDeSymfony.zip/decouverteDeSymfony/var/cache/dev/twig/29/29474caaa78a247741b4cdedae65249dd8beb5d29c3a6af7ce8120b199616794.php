<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_2a53bc253a0b4816d6894cf7a3fb288f9368a4ad6f2639f7d55629ac07c7171e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_add04d2ef64c4f9c2535e9fc26e87aabaa4b04eb7df759efc07579c48df50c54 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_add04d2ef64c4f9c2535e9fc26e87aabaa4b04eb7df759efc07579c48df50c54->enter($__internal_add04d2ef64c4f9c2535e9fc26e87aabaa4b04eb7df759efc07579c48df50c54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_5fa318ae4ce167d99202d153ba61bb218d012645e12e8b055d29f3d3511b010e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5fa318ae4ce167d99202d153ba61bb218d012645e12e8b055d29f3d3511b010e->enter($__internal_5fa318ae4ce167d99202d153ba61bb218d012645e12e8b055d29f3d3511b010e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_add04d2ef64c4f9c2535e9fc26e87aabaa4b04eb7df759efc07579c48df50c54->leave($__internal_add04d2ef64c4f9c2535e9fc26e87aabaa4b04eb7df759efc07579c48df50c54_prof);

        
        $__internal_5fa318ae4ce167d99202d153ba61bb218d012645e12e8b055d29f3d3511b010e->leave($__internal_5fa318ae4ce167d99202d153ba61bb218d012645e12e8b055d29f3d3511b010e_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_a1e3cda261fe4e4bd05aae64e5c3ddf6b33611d511fc8273f0f18d23234da45c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1e3cda261fe4e4bd05aae64e5c3ddf6b33611d511fc8273f0f18d23234da45c->enter($__internal_a1e3cda261fe4e4bd05aae64e5c3ddf6b33611d511fc8273f0f18d23234da45c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_63af2c5267862fd782034c2df9e0c2d2f3d872de3d953db50f08839490e64a34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63af2c5267862fd782034c2df9e0c2d2f3d872de3d953db50f08839490e64a34->enter($__internal_63af2c5267862fd782034c2df9e0c2d2f3d872de3d953db50f08839490e64a34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_63af2c5267862fd782034c2df9e0c2d2f3d872de3d953db50f08839490e64a34->leave($__internal_63af2c5267862fd782034c2df9e0c2d2f3d872de3d953db50f08839490e64a34_prof);

        
        $__internal_a1e3cda261fe4e4bd05aae64e5c3ddf6b33611d511fc8273f0f18d23234da45c->leave($__internal_a1e3cda261fe4e4bd05aae64e5c3ddf6b33611d511fc8273f0f18d23234da45c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp64\\www\\talanAcademy\\Symfony\\DecouverteDeSymfony-Act-3.1\\decouverteDeSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
