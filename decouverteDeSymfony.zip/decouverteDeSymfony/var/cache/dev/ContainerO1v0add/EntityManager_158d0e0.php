<?php

class EntityManager_158d0e0 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $valueHolder61787489dc166876708269 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer61787489dc16e802626041 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties61787489dc14e693642821 = array(
        
    );

    /**
     * {@inheritDoc}
     */
    public function getConnection()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getConnection', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getConnection();
    }

    /**
     * {@inheritDoc}
     */
    public function getMetadataFactory()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getMetadataFactory', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getMetadataFactory();
    }

    /**
     * {@inheritDoc}
     */
    public function getExpressionBuilder()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getExpressionBuilder', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getExpressionBuilder();
    }

    /**
     * {@inheritDoc}
     */
    public function beginTransaction()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'beginTransaction', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->beginTransaction();
    }

    /**
     * {@inheritDoc}
     */
    public function getCache()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getCache', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getCache();
    }

    /**
     * {@inheritDoc}
     */
    public function transactional($func)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'transactional', array('func' => $func), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->transactional($func);
    }

    /**
     * {@inheritDoc}
     */
    public function commit()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'commit', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->commit();
    }

    /**
     * {@inheritDoc}
     */
    public function rollback()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'rollback', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->rollback();
    }

    /**
     * {@inheritDoc}
     */
    public function getClassMetadata($className)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getClassMetadata', array('className' => $className), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getClassMetadata($className);
    }

    /**
     * {@inheritDoc}
     */
    public function createQuery($dql = '')
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'createQuery', array('dql' => $dql), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->createQuery($dql);
    }

    /**
     * {@inheritDoc}
     */
    public function createNamedQuery($name)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'createNamedQuery', array('name' => $name), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->createNamedQuery($name);
    }

    /**
     * {@inheritDoc}
     */
    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->createNativeQuery($sql, $rsm);
    }

    /**
     * {@inheritDoc}
     */
    public function createNamedNativeQuery($name)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->createNamedNativeQuery($name);
    }

    /**
     * {@inheritDoc}
     */
    public function createQueryBuilder()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'createQueryBuilder', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->createQueryBuilder();
    }

    /**
     * {@inheritDoc}
     */
    public function flush($entity = null)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'flush', array('entity' => $entity), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->flush($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function find($entityName, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'find', array('entityName' => $entityName, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->find($entityName, $id, $lockMode, $lockVersion);
    }

    /**
     * {@inheritDoc}
     */
    public function getReference($entityName, $id)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getReference($entityName, $id);
    }

    /**
     * {@inheritDoc}
     */
    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getPartialReference($entityName, $identifier);
    }

    /**
     * {@inheritDoc}
     */
    public function clear($entityName = null)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'clear', array('entityName' => $entityName), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->clear($entityName);
    }

    /**
     * {@inheritDoc}
     */
    public function close()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'close', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->close();
    }

    /**
     * {@inheritDoc}
     */
    public function persist($entity)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'persist', array('entity' => $entity), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->persist($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function remove($entity)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'remove', array('entity' => $entity), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->remove($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function refresh($entity)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'refresh', array('entity' => $entity), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->refresh($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function detach($entity)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'detach', array('entity' => $entity), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->detach($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function merge($entity)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'merge', array('entity' => $entity), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->merge($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function copy($entity, $deep = false)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->copy($entity, $deep);
    }

    /**
     * {@inheritDoc}
     */
    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->lock($entity, $lockMode, $lockVersion);
    }

    /**
     * {@inheritDoc}
     */
    public function getRepository($entityName)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getRepository', array('entityName' => $entityName), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getRepository($entityName);
    }

    /**
     * {@inheritDoc}
     */
    public function contains($entity)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'contains', array('entity' => $entity), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->contains($entity);
    }

    /**
     * {@inheritDoc}
     */
    public function getEventManager()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getEventManager', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getEventManager();
    }

    /**
     * {@inheritDoc}
     */
    public function getConfiguration()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getConfiguration', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getConfiguration();
    }

    /**
     * {@inheritDoc}
     */
    public function isOpen()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'isOpen', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->isOpen();
    }

    /**
     * {@inheritDoc}
     */
    public function getUnitOfWork()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getUnitOfWork', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getUnitOfWork();
    }

    /**
     * {@inheritDoc}
     */
    public function getHydrator($hydrationMode)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getHydrator($hydrationMode);
    }

    /**
     * {@inheritDoc}
     */
    public function newHydrator($hydrationMode)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->newHydrator($hydrationMode);
    }

    /**
     * {@inheritDoc}
     */
    public function getProxyFactory()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getProxyFactory', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getProxyFactory();
    }

    /**
     * {@inheritDoc}
     */
    public function initializeObject($obj)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'initializeObject', array('obj' => $obj), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->initializeObject($obj);
    }

    /**
     * {@inheritDoc}
     */
    public function getFilters()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'getFilters', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->getFilters();
    }

    /**
     * {@inheritDoc}
     */
    public function isFiltersStateClean()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'isFiltersStateClean', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->isFiltersStateClean();
    }

    /**
     * {@inheritDoc}
     */
    public function hasFilters()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'hasFilters', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return $this->valueHolder61787489dc166876708269->hasFilters();
    }

    /**
     * @override constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public function __construct($initializer)
    {
        $this->initializer61787489dc16e802626041 = $initializer;
    }

    /**
     * @param string $name
     */
    public function & __get($name)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, '__get', array('name' => $name), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        if (isset(self::$publicProperties61787489dc14e693642821[$name])) {
            return $this->valueHolder61787489dc166876708269->$name;
        }

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder61787489dc166876708269;

            $backtrace = debug_backtrace(false);
            trigger_error('Undefined property: ' . get_parent_class($this) . '::$' . $name . ' in ' . $backtrace[0]['file'] . ' on line ' . $backtrace[0]['line'], \E_USER_NOTICE);
            return $targetObject->$name;;
            return;
        }

        $targetObject = $this->valueHolder61787489dc166876708269;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    /**
     * @param string $name
     * @param mixed $value
     */
    public function __set($name, $value)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder61787489dc166876708269;

            return $targetObject->$name = $value;;
            return;
        }

        $targetObject = $this->valueHolder61787489dc166876708269;
        $accessor = function & () use ($targetObject, $name, $value) {
            return $targetObject->$name = $value;
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    /**
     * @param string $name
     */
    public function __isset($name)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, '__isset', array('name' => $name), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder61787489dc166876708269;

            return isset($targetObject->$name);;
            return;
        }

        $targetObject = $this->valueHolder61787489dc166876708269;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    /**
     * @param string $name
     */
    public function __unset($name)
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, '__unset', array('name' => $name), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder61787489dc166876708269;

            unset($targetObject->$name);;
            return;
        }

        $targetObject = $this->valueHolder61787489dc166876708269;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
            $backtrace = debug_backtrace(true);
            $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \stdClass();
            $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __clone()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, '__clone', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        $this->valueHolder61787489dc166876708269 = clone $this->valueHolder61787489dc166876708269;
    }

    public function __sleep()
    {
        $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, '__sleep', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;

        return array('valueHolder61787489dc166876708269');
    }

    public function __wakeup()
    {
    }

    /**
     * {@inheritDoc}
     */
    public function setProxyInitializer(\Closure $initializer = null)
    {
        $this->initializer61787489dc16e802626041 = $initializer;
    }

    /**
     * {@inheritDoc}
     */
    public function getProxyInitializer()
    {
        return $this->initializer61787489dc16e802626041;
    }

    /**
     * {@inheritDoc}
     */
    public function initializeProxy()
    {
        return $this->initializer61787489dc16e802626041 && ($this->initializer61787489dc16e802626041->__invoke($valueHolder61787489dc166876708269, $this, 'initializeProxy', array(), $this->initializer61787489dc16e802626041) || 1) && $this->valueHolder61787489dc166876708269 = $valueHolder61787489dc166876708269;
    }

    /**
     * {@inheritDoc}
     */
    public function isProxyInitialized()
    {
        return null !== $this->valueHolder61787489dc166876708269;
    }

    /**
     * {@inheritDoc}
     */
    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder61787489dc166876708269;
    }


}
