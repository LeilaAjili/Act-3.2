<?php

namespace AppBundle\Controller;

use AppBundle\Entity\User;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;




class UserController extends Controller{

    /**
     * @Route("/getAll", name="Users List")
     */

    public function index() {

        $users = $this->getDoctrine()->getRepository(User::class)->findAll();


        return $this->render('users/index.html.twig', array('users'=>$users));
    }

    /**
     * @Route("/user/{id}", name="user_show")
     */

     public function show($id){
         $user = $this->getDoctrine()->getRepository(User::class)->find($id);

         return $this->render('users/show.html.twig', array('user' => $user));
     }

   
     /**
     * @Route("/create", name="user_create")
     */

     public function createUser (){

         $entityManager = $this->getDoctrine()->getManager();

         $user = new User();

         $user->setFirstName('Leila');

         $user->setLastName('Ajili');

         $user->setEmail('leila@gmail.com');

         $user->setAdress('Tunis');

         $user->setBirthdate(new \DateTime(1985-10-26));

        

         

         $entityManager->persist($user);

         $entityManager->flush();

         return new Response('saved user '.$user->getFirstName());




     }
}